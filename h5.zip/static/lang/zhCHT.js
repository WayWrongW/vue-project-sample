module.exports={
  message: {
	 
		   hello: '你好',
		 about: '關於',
		 welcome: "歡迎",
		 toast:"繁體很好"
		  
	 
  
  }
}