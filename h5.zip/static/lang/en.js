module.exports={
  todo: {
		balance: 'Task balance',
		transfer: 'Transfer pledge',
		sign: 'Continuous sign in for benefits',
		signed:'Continuous sign',
		day:'day',
		days:'days',
		nosign:'No sign',
		the:'',
		mei:'',
		daily:'Reward for daily tasks',
		invatation: 'Invite friends to get airdrop reward',
		invatation_content: 'For each successful friend invited, 0.1 hzwz will be awarded.',
		receive: 'receive',
		change_head: 'change the avatar',
		head_receive: 'You have to see without a reward',
		read1:'Read the details of project funding',
		read1_content: 'You have to see without a reward',
		read2: 'Read the project ecological construction rules'
  },
  ftb_index:{
	  lang: '中文',
	  about:'ABOUT',
	  title:'Football Coin',
	  intro:'FTB is a token on Binance Smart Chain boasting a number of impressive features. It is the first token with a Black Hole design that exponentially cuts the total supply in circulation by massive amounts. FTB combines this with an innovative Auto-Liquidity feature that increases liquidity of the token rapidly. And finally, FTB has massive decentralization on a scale rarely seen in other tokens. Combine these three together and you get a power house token out of the hands of anyone, except the community as a whole.',
	  blackhole:'BLACK HOLE',
	  algorithm:'ALGORITHM',
	  blackhole_intro:'The Black Hole owned over 50% of supply at launch. The Black Hole counts as one of the wallet holders that 2% of transactions are distributed to. This results in exponential growth of the black hole and exponential burn of the token supply. At the time of this writing, the black hole has already grown to 55% percent ownership of the total supply.',
	  buy:'Buy Now'
	  
  },
  BPC_index:{
	  AirDrop:"AirDrop",
	  lang: '中文',
	  Home:"Home",
	  TOKENOMICS:"TOKENOMICS",
	  ContactUs:"Contact Us",
	  AboutBPC:"About BPC",
	  about:"Baby Puppy(BPC) has learned a few tricks and lessons from his father, Doge Coin. Birthed by fans of the Doge Coin community. Baby Puppy seeks to impress his father by showing his new improved speed. He is Hyper-deflationary with an integrated smart staking system built in so more baby puppy are always being added to your wallet. Simply Love, pet, and watch your baby puppy grow.",
	  buy: "Buy Now",
	  copyAddress:"copy Address",
	  MaxTotalSupply:"Max Total Supply",
	  Burntindeadwallet:"Burnt in dead wallet",
	  Burntdirectfromsupply:"Burnt direct from supply",
	  HOW:"HOW",
	  howdata1:'15% per transaction tax, including',
	  howdata2:'5% will be burnt forever',
	  howdata3:'5% goes token holders',
	  howdata4:'5% goes to sent and locked into pancake swap liquidity pools.',
	  howdata5:'No Vesting, No Dev Token',
	  airdropRules:'Airdrop rules: Please use a browser or wallet software (tp, imtoken, etc.) that supports web3 to open the link. Each wallet address can receive 30,000 airdrops (there is a limit, don’t think about generating addresses indefinitely), every time you invite a friend, you can Add 10000 airdrops without capping',
	  share:'Click to share',
	  balance:"balance",
	  CLIAM:'Ended',
	  Insufficient:"Insufficient balance"

  },
  tabBar:
		[{
				index: 0,
			    text: 'TODO'
			    // iconPath: '/path/to/iconPath',
			    // selectedIconPath: '/path/to/selectedIconPath'
		},
		{
				index: 1,
			    text: 'MINT'
			    // iconPath: '/path/to/iconPath',
			    // selectedIconPath: '/path/to/selectedIconPath'
		}]
  
}